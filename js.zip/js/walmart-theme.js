/* ===== WALMART FRONTEND THEME JAVASCRIPT ===== */

(function($) {
    'use strict';

    // Initialize when document is ready
    $(document).ready(function() {
        initWalmartFrontend();
    });

    function initWalmartFrontend() {
        // Initialize mobile menu
        initMobileMenu();
        
        // Initialize search functionality
        initSearch();
        
        // Initialize cart/wishlist dropdowns
        initDropdowns();
        
        // Initialize product interactions
        initProductInteractions();
        
        // Initialize scroll effects
        initScrollEffects();
        
        // Initialize tooltips
        initTooltips();
    }

    // Mobile Menu Functionality
    function initMobileMenu() {
        // Toggle mobile menu
        $(document).on('click', '.mobile-menu-toggle', function() {
            $('.walmart-mainmenu').toggleClass('show');
            $('.mobile-menu-overlay').toggleClass('show');
            $('body').toggleClass('menu-open');
        });

        // Close mobile menu when clicking overlay
        $(document).on('click', '.mobile-menu-overlay', function() {
            $('.walmart-mainmenu').removeClass('show');
            $('.mobile-menu-overlay').removeClass('show');
            $('body').removeClass('menu-open');
        });

        // Handle dropdown toggles in mobile menu
        $(document).on('click', '.walmart-dropdown .dropdown-toggle', function(e) {
            if ($(window).width() <= 991) {
                e.preventDefault();
                const $dropdown = $(this).closest('.walmart-dropdown');
                const $menu = $dropdown.find('.walmart-dropdown-menu');
                
                // Toggle current dropdown
                $dropdown.toggleClass('active');
                
                // Close other dropdowns
                $('.walmart-dropdown').not($dropdown).removeClass('active');
                
                // Rotate arrow
                const $arrow = $(this).find('.dropdown-arrow');
                if ($dropdown.hasClass('active')) {
                    $arrow.css('transform', 'rotate(180deg)');
                } else {
                    $arrow.css('transform', 'rotate(0deg)');
                }
            }
        });

        // Handle submenu toggles in mobile menu
        $(document).on('click', '.walmart-dropdown-submenu > a', function(e) {
            if ($(window).width() <= 991) {
                e.preventDefault();
                const $submenu = $(this).closest('.walmart-dropdown-submenu');
                const $submenuList = $submenu.find('.walmart-submenu');
                
                // Toggle current submenu
                $submenu.toggleClass('active');
                
                // Close other submenus
                $('.walmart-dropdown-submenu').not($submenu).removeClass('active');
                
                // Rotate arrow
                const $arrow = $(this).find('.submenu-arrow');
                if ($submenu.hasClass('active')) {
                    $arrow.css('transform', 'rotate(90deg)');
                } else {
                    $arrow.css('transform', 'rotate(0deg)');
                }
            }
        });

        // Close mobile menu when clicking a regular nav link (not dropdown)
        $(document).on('click', '.walmart-nav-list a:not(.dropdown-toggle)', function() {
            if ($(window).width() <= 991) {
                $('.walmart-mainmenu').removeClass('show');
                $('.mobile-menu-overlay').removeClass('show');
                $('body').removeClass('menu-open');
            }
        });

        // Handle window resize
        $(window).resize(function() {
            if ($(window).width() > 991) {
                $('.walmart-mainmenu').removeClass('show');
                $('.mobile-menu-overlay').removeClass('show');
                $('body').removeClass('menu-open');
                // Reset mobile dropdown states
                $('.walmart-dropdown').removeClass('active');
                $('.walmart-dropdown-submenu').removeClass('active');
                $('.dropdown-arrow, .submenu-arrow').css('transform', '');
            }
        });
    }

    // Search Functionality
    function initSearch() {
        // Search form enhancements
        $('.search-input').on('focus', function() {
            $(this).closest('.search-input-group').addClass('focused');
        }).on('blur', function() {
            $(this).closest('.search-input-group').removeClass('focused');
        });

        // Search suggestions (if needed)
        $('.search-input').on('input', function() {
            const query = $(this).val();
            if (query.length > 2) {
                // Implement search suggestions here
                // showSearchSuggestions(query);
            }
        });

        // Category select change
        $('.category-select').on('change', function() {
            const category = $(this).val();
            // Update search context based on category
            updateSearchPlaceholder(category);
        });
    }

    function updateSearchPlaceholder(category) {
        const input = $('.search-input');
        if (category) {
            const categoryText = $('.category-select option:selected').text();
            input.attr('placeholder', `Search in ${categoryText}...`);
        } else {
            input.attr('placeholder', 'Search everything at E-Shop...');
        }
    }

    // Dropdown Functionality
    function initDropdowns() {
        // Cart/Wishlist dropdown toggle
        $(document).on('click', '.walmart-icon-btn', function(e) {
            const $dropdown = $(this).siblings('.shopping-item');
            if ($dropdown.length > 0) {
                e.preventDefault();
                e.stopPropagation();
                
                // Close other dropdowns
                $('.shopping-item').not($dropdown).removeClass('show');
                
                // Toggle current dropdown
                $dropdown.toggleClass('show');
            }
        });

        // Close dropdowns when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.sinlge-bar').length) {
                $('.shopping-item').removeClass('show');
            }
        });

        // Close dropdown when pressing Escape
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                $('.shopping-item').removeClass('show');
            }
        });
    }

    // Product Interactions
    function initProductInteractions() {
        // Add to cart button loading state
        $(document).on('click', '.add-to-cart', function() {
            const $btn = $(this);
            const originalText = $btn.html();
            
            $btn.html('<i class="fa fa-spinner fa-spin"></i> Adding...');
            $btn.prop('disabled', true);
            
            // Simulate loading (replace with actual AJAX call)
            setTimeout(function() {
                $btn.html('<i class="fa fa-check"></i> Added!');
                setTimeout(function() {
                    $btn.html(originalText);
                    $btn.prop('disabled', false);
                }, 1000);
            }, 1000);
        });

        // Wishlist button toggle
        $(document).on('click', '.wishlist-btn', function(e) {
            e.preventDefault();
            const $btn = $(this);
            const $icon = $btn.find('i');
            
            if ($icon.hasClass('fa-heart-o')) {
                $icon.removeClass('fa-heart-o').addClass('fa-heart');
                $btn.addClass('active');
                showNotification('Added to wishlist!', 'success');
            } else {
                $icon.removeClass('fa-heart').addClass('fa-heart-o');
                $btn.removeClass('active');
                showNotification('Removed from wishlist!', 'info');
            }
        });

        // Product image hover effects
        $('.single-product').hover(
            function() {
                $(this).addClass('hover');
            },
            function() {
                $(this).removeClass('hover');
            }
        );

        // Quick view functionality
        $(document).on('click', '.quick-view-btn', function(e) {
            e.preventDefault();
            const productId = $(this).data('product-id');
            // Implement quick view modal
            showQuickView(productId);
        });
    }

    // Scroll Effects
    function initScrollEffects() {
        // Header scroll effect
        let lastScrollTop = 0;
        $(window).scroll(function() {
            const scrollTop = $(this).scrollTop();
            const header = $('.walmart-header');
            
            if (scrollTop > lastScrollTop && scrollTop > 100) {
                // Scrolling down
                header.addClass('header-hidden');
            } else {
                // Scrolling up
                header.removeClass('header-hidden');
            }
            
            lastScrollTop = scrollTop;
        });

        // Smooth scroll for anchor links
        $('a[href^="#"]').on('click', function(e) {
            e.preventDefault();
            const target = $($(this).attr('href'));
            if (target.length) {
                $('html, body').animate({
                    scrollTop: target.offset().top - 100
                }, 500);
            }
        });

        // Back to top button
        if ($('.back-to-top').length === 0) {
            $('body').append('<button class="back-to-top"><i class="fa fa-chevron-up"></i></button>');
        }

        $(window).scroll(function() {
            if ($(this).scrollTop() > 300) {
                $('.back-to-top').addClass('show');
            } else {
                $('.back-to-top').removeClass('show');
            }
        });

        $(document).on('click', '.back-to-top', function() {
            $('html, body').animate({scrollTop: 0}, 500);
        });
    }

    // Initialize Tooltips
    function initTooltips() {
        if (typeof $().tooltip === 'function') {
            $('[data-toggle="tooltip"], [title]').tooltip({
                container: 'body',
                trigger: 'hover'
            });
        }
    }

    // Utility Functions
    function showNotification(message, type = 'info') {
        const notification = $(`
            <div class="walmart-notification walmart-notification-${type}">
                <div class="notification-content">
                    <i class="fa fa-${getNotificationIcon(type)}"></i>
                    <span>${message}</span>
                </div>
                <button class="notification-close">
                    <i class="fa fa-times"></i>
                </button>
            </div>
        `);

        $('body').append(notification);
        
        setTimeout(function() {
            notification.addClass('show');
        }, 100);

        setTimeout(function() {
            notification.removeClass('show');
            setTimeout(function() {
                notification.remove();
            }, 300);
        }, 3000);

        // Close button
        notification.find('.notification-close').on('click', function() {
            notification.removeClass('show');
            setTimeout(function() {
                notification.remove();
            }, 300);
        });
    }

    function getNotificationIcon(type) {
        switch (type) {
            case 'success': return 'check-circle';
            case 'error': return 'exclamation-circle';
            case 'warning': return 'exclamation-triangle';
            case 'info': return 'info-circle';
            default: return 'info-circle';
        }
    }

    function showQuickView(productId) {
        // Implement quick view modal
        console.log('Quick view for product:', productId);
        // This would typically load product data via AJAX and show in a modal
    }

    // Global Walmart Frontend object
    window.WalmartFrontend = {
        // Show loading state
        showLoading: function(element) {
            const $element = $(element);
            const originalText = $element.html();
            $element.data('original-text', originalText);
            $element.html('<i class="fa fa-spinner fa-spin"></i> Loading...');
            $element.prop('disabled', true);
        },

        // Hide loading state
        hideLoading: function(element) {
            const $element = $(element);
            const originalText = $element.data('original-text');
            if (originalText) {
                $element.html(originalText);
            }
            $element.prop('disabled', false);
        },

        // Show notification
        showNotification: showNotification,

        // Format currency
        formatCurrency: function(amount, currency = '$') {
            return currency + parseFloat(amount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        },

        // Update cart count
        updateCartCount: function(count) {
            $('.walmart-cart .walmart-badge').text(count);
        },

        // Update wishlist count
        updateWishlistCount: function(count) {
            $('.walmart-wishlist .walmart-badge').text(count);
        },

        // Animate number counting
        animateNumber: function(element, start, end, duration = 1000) {
            const $element = $(element);
            const range = end - start;
            const increment = range / (duration / 16);
            let current = start;
            
            const timer = setInterval(function() {
                current += increment;
                if (current >= end) {
                    current = end;
                    clearInterval(timer);
                }
                $element.text(Math.floor(current));
            }, 16);
        }
    };

    // Initialize theme when page loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initWalmartFrontend);
    } else {
        initWalmartFrontend();
    }

})(jQuery);